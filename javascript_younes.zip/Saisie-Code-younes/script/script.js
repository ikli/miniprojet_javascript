//********younes ikli*************************************************************

var numeros = [0,1,2,3,4,5,6,7,8,9];
var etoiles = "****";
var  tt= document.getElementsByClassName("digit");
document.getElementById("code").innerHTML =  etoiles;


//********************************************************************************

function aleatoire(x) {
                      var j, k, i;
                      for (i = x.length - 1; i > 0; i--) {
                                                         j = Math.floor(Math.random() * (i + 1));
                                                         k = x[i];
                                                         x[i] = x[j];
                                                         x[j] = k;
                                                           }
                      return x;
                      }

aleatoire(numeros);


//**********************************************************************************

function bclick(numeros,test){
                              var div = "" ;
                              for (var i = 5*test; i<(5*(test+1)); i++){
                                                                            div += "<button class=\"digit\">"+numeros[i]+"</button>" ;
                                                                           }
                               return div ;
                              }

 // test vaut ici soit 0 ou 1 
//0 pour premiers valeurs du tableau de numeros
//1 pour derniers valeurs du tableau de numeros

document.getElementById("line1").innerHTML = bclick(numeros,0);
document.getElementById("line2").innerHTML = bclick(numeros,1);


//**********************************************************************************

function write_code(num){
                        var num = this.textContent; 
                        var l = document.getElementById("code").textContent;
                        var i = 0;    
                        while (l[i] !== '*' &&  i<4){
                                                    i=i+1;
                                                    }
  
                       var clk = "";
                       for (var j = 0;j < 4; j++){
                                                 if (j !== i){
                                                             clk= clk+l[j];
                                                              }
                                                 else{
                                                      clk=clk+num;
                                                     }
                                                  }

   
                       document.getElementById("code").textContent = clk;


                       if(i === 3){                      
                                  for(var k = 0; k<10;k++){
                                                           tt[k].setAttribute("disabled","");
                                                          }
                                  }
                          }


//******************************************************************************************

for (var n = 0; n < tt.length; n++) {
                                    tt[n].addEventListener('click', write_code);
                                    }



var image = document.getElementById("diapo");
var numdiapo = document.getElementById("idxImage");
var start = document.getElementById("startButton");
var stop = document.getElementById("stopButton");
var nextBnt = document.getElementById("nextButton");
var prevBnt = document.getElementById("previousButton");
var delai = document.getElementById("diapoStep");
var i = 1;
var index = 0 ;

start.addEventListener("click",slideshow);
stop.addEventListener("click",stopSlider);
nextBnt.addEventListener("click", nextPict) ;
prevBnt.addEventListener("click", prevPict);
 


function stopSlider() {
	                  window.clearInterval(timer1);
	                   }


function slideshow() {
                      timer1 = window.setInterval(nextPict,delai.value*1000);   
                      numdiapo.value = index ;                                       
                     }


function nextPict () {
                      var i = index ;
                      index = (i + 1) % 8 ;
	                  image.src = tabImages[i];
                      numdiapo.value = index ;
                      }
                     

function prevPict () {
                      var i = index  ;
                      index = (i - 1) % 8;	                  
                      if (index < 0){
		                            index = 7;
                                    }
                      image.src = tabImages[i];
                      numdiapo.value = index ;
                      }



